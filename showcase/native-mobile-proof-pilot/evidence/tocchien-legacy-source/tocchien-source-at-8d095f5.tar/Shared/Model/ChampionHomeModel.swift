//
//  ChampionHomeModel.swift
//  TocChienGuide
//
//  Created by Jang Trinh on 18/03/2021.
//

import SwiftUI

struct ChampionHomeModel: Identifiable, Hashable {
    var id = UUID()
    var name: String
    var image: String
    var description: String
    var subtitle: String
}

var championhomemodels = [
    ChampionHomeModel(
        name: "Lux",
        image: "champion_overview_lux_spellthief",
        description: "Lux là pháp sư ánh sáng chuyên trói chân địch, tạo lá chắn cho đồng minh và gây sát thương cực lớn. Thứ duy nhất tỏa sáng chói lóa hơn phép thuật là thái độ tươi vui của cô.",
        subtitle: "TIỂU THƯ ÁNH SÁNG"
    ),
    ChampionHomeModel(
        name: "Jinx",
        image: "champion_overview_jinx_zombieslay",
        description: "Jinx là xạ thủ với lối chơi Thích là bắn và kho vũ khí đầy các khẩu súng và công cụ nguy hiểm. Cháy nổ là chuyện miễn bàn với cô nàng.",
        subtitle: "KHẨU PHÁO NỔI LOẠN"
    ),
    ChampionHomeModel(
        name: "Zed",
        image: "champion_overview_zed_deathsworn",
        description: "Là một tên sát thủ đáng sợ, Zed hạ thủ kẻ địch từ trong bóng tối, rồi biến mất. Nếu bạn thấy hắn tức là mọi thứ đã quá trễ rồi.",
        subtitle: "HỘI TỬ THẦN"
    ),
    ChampionHomeModel(
        name: "Miss fortune",
        image: "champion_overview_ms",
        description: "Miss Fortune là xạ thủ tàn nhẫn với hai khẩu súng lục vung vẩy, vừa đường hoàng tự tin vừa cool ngầu bá đạo. Cô luôn sẵn sàng làm mưa tuôn rơi. Mưa đạn đó.",
        subtitle: "THỢ SĂN TIỀN THƯỞNG"
    ),
    ChampionHomeModel(
        name: "Blitzcrank",
        image: "champion_overview_blitzcrank",
        description: "Là tướng hỗ trợ, Blitzcrank luôn sẵn sàng ra tay tương trợ bạn theo đúng nghĩa đen. Bằng cách kéo mục tiêu địch vào giữa giao tranh, hắn sẽ mở đầu trận chiến dù kẻ địch có sẵn sàng hay chưa.",
        subtitle: "NGƯỜI MÁY HƠI NƯỚC"
    ),
    ChampionHomeModel(
        name: "Ziggs",
        image: "champion_overview_ziggs",
        description: "Ziggs là pháp sư thuốc nổ luôn thủ sẵn 1 (hoặc cũng có thể là 4) quả bom trong ống tay áo. Hắn chuyên sử dụng các loại bom ngòi nổ ngắn, bom to và cho địch banh xác thành từng mảnh.",
        subtitle: "CHUYÊN GIA CHẤT NỔ"
    )
]
