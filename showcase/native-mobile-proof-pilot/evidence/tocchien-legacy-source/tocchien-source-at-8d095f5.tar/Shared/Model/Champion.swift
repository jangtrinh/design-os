//
//  Champion.swift
//  TocChienGuide
//
//  Created by Jang Trinh on 19/02/2021.
//

import SwiftUI

struct Champion: Identifiable, Hashable {
    
    var id = UUID()
    var name: String
    var url: String
    var type: String
    var difficult:Double
    var damagetype: String
    var image: String
    var skinindex: Double
    var show: Bool
}

    var champions = [
        Champion(
            name:"Ahri",
            url:"ahri",
            type:"Pháp sư / Sát thủ",
            difficult:2,
            damagetype:"100% Phép Thuật",
            image:"ahri_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Akali",
            url:"akali",
            type:"Sát thủ",
            difficult:3,
            damagetype:"38% Phép Thuật - 62% Vật Lý",
            image:"akali_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Alistar",
            url:"alistar",
            type:"Đỡ đòn / Hỗ trợ",
            difficult:1,
            damagetype:"50% Phép Thuật - 50% Vật Lý",
            image:"alistar_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Amumu",
            url:"amumu",
            type:"Đỡ đòn",
            difficult:1,
            damagetype:"100% Phép Thuật",
            image:"amumu_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Annie",
            url:"annie",
            type:"Pháp sư / Hỗ trợ",
            difficult:1,
            damagetype:"100% Phép Thuật",
            image:"annie_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Ashe",
            url:"ashe",
            type:"Xạ thủ / Hỗ trợ",
            difficult:1,
            damagetype:"13% Phép Thuật - 87% Vật Lý",
            image:"ashe_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Aurelion Sol",
            url:"aurelion-sol",
            type:"Pháp sư",
            difficult:3,
            damagetype:"100% Phép Thuật",
            image:"aurelionsol_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"BlitzCrank",
            url:"blitzcrank",
            type:"Đỡ đòn / Hỗ trợ",
            difficult:1,
            damagetype:"100% Phép Thuật",
            image:"blitzcrank_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Braum",
            url:"braum",
            type:"Hỗ trợ / Đỡ đòn",
            difficult:2,
            damagetype:"75% Phép Thuật - 25% Vật Lý",
            image:"braum_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Camille",
            url:"camille",
            type:"Đấu sĩ",
            difficult:3,
            damagetype:"25% Phép Thuật - 75% Vật Lý",
            image:"camille_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Corki",
            url:"corki",
            type:"Xạ thủ",
            difficult:2,
            damagetype:"75% Phép Thuật - 25% Vật Lý",
            image:"Corki_ChampThumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Darius",
            url:"darius",
            type:"Đấu sĩ",
            difficult:2,
            damagetype:"100% Vật Lý",
            image:"Darius_ChampThumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Draven",
            url:"draven",
            type:"Xạ thủ",
            difficult:3,
            damagetype:"100% Vật Lý",
            image:"Draven_ChampThumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Dr.Mundo",
            url:"dr-mundo",
            type:"Đấu sĩ / Đỡ đòn",
            difficult:1,
            damagetype:"50% Phép Thuật - 50% Vật Lý",
            image:"drmundo_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Evelynn",
            url:"evelynn",
            type:"Sát thủ",
            difficult:2,
            damagetype:"100% Phép Thuật",
            image:"evelynn_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Ezreal",
            url:"ezreal",
            type:"Xạ thủ / Pháp sư",
            difficult:2,
            damagetype:"25% Phép Thuật - 75% Vật Lý",
            image:"ezreal_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Fiora",
            url:"fiora",
            type:"Đấu sĩ / Sát thủ",
            difficult:3,
            damagetype:"100% Vật Lý",
            image:"fiora_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Fizz",
            url:"fizz",
            type:"Sát thủ / Pháp sư",
            difficult:2,
            damagetype:"100% Phép Thuật",
            image:"fizz_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Garen",
            url:"garen",
            type:"Đấu sĩ / Đỡ đòn",
            difficult:1,
            damagetype:"25% Phép Thuật - 75% Vật Lý",
            image:"garen_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Gragas",
            url:"gragas",
            type:"Đỡ đòn / Pháp sư",
            difficult:2,
            damagetype:"100% Phép Thuật",
            image:"gragas_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Graves",
            url:"graves",
            type:"Xạ thủ / Đấu sĩ",
            difficult:2,
            damagetype:"100% Vật Lý",
            image:"graves_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Janna",
            url:"janna",
            type:"Hỗ trợ / Pháp sư",
            difficult:1,
            damagetype:"100% Phép Thuật",
            image:"janna_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Jarvan IV",
            url:"jarvan-iv",
            type:"Đỡ đòn / Đấu sĩ",
            difficult:1,
            damagetype:"100% Phép Thuật",
            image:"jarvaniv_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Jax",
            url:"jax",
            type:"Đấu sĩ",
            difficult:2,
            damagetype:"50% Phép Thuật - 50% Vật Lý",
            image:"jax_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Jhin",
            url:"jhin",
            type:"Xạ thủ / Pháp sư",
            difficult:2,
            damagetype:"100% Vật Lý",
            image:"jhin_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Jinx",
            url:"jinx",
            type:"Xạ thủ",
            difficult:2,
            damagetype:"100% Vật Lý",
            image:"jinx_champthumb",
            skinindex:4,
            show:false
        ),
        
        Champion(
            name:"Katarina",
            url:"katarina",
            type:"Sát thủ / Pháp Sư",
            difficult:3,
            damagetype:"50% Phép Thuật - 50% Vật Lý",
            image:"katarina_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Kaisa",
            url:"kaisa",
            type:"Xạ thủ / Sát thủ",
            difficult:2,
            damagetype:"50% Phép Thuật - 50% Vật Lý",
            image:"kaisa_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Kennen",
            url:"kennen",
            type:"Pháp sư / Xạ thủ",
            difficult:2,
            damagetype:"75% Phép Thuật - 25% Vật Lý",
            image:"Kennen_ChampThumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Lee Sin",
            url:"lee-sin",
            type:"Đấu sĩ / Sát thủ",
            difficult:2,
            damagetype:"100% Vật Lý",
            image:"leesin_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Lulu",
            url:"lulu",
            type:"Hỗ trợ / Pháp sư",
            difficult:2,
            damagetype:"Sát thương phép thuật",
            image:"Lulu_ChampThumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Lux",
            url:"lux",
            type:"Pháp sư / Hỗ trợ",
            difficult:1,
            damagetype:"100% Phép Thuật",
            image:"lux_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Malphite",
            url:"malphite",
            type:"Đỡ đòn",
            difficult:1,
            damagetype:"75% Phép Thuật - 25% Vật Lý",
            image:"malphite_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Master YI",
            url:"master-yi",
            type:"Sát thủ / Đấu sĩ",
            difficult:1,
            damagetype:"100% Vật Lý",
            image:"masteryi_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Miss Fortune",
            url:"miss-fortune",
            type:"Xạ thủ / Pháp sư",
            difficult:1,
            damagetype:"25% Phép Thuật - 75% Vật Lý",
            image:"missfortune_champthumb",
            skinindex:5,
            show:false
        ),
        Champion(
            name:"Nami",
            url:"nami",
            type:"Hỗ trợ / Pháp sư",
            difficult:2,
            damagetype:"100% Phép Thuật",
            image:"nami_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Nasus",
            url:"nasus",
            type:"Đấu sĩ / Đỡ đòn",
            difficult:1,
            damagetype:"25% Phép Thuật - 75% Vật Lý",
            image:"nasus_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Olaf",
            url:"olaf",
            type:"Đấu sĩ",
            difficult:2,
            damagetype:"100% Vật Lý",
            image:"olaf_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Orianna",
            url:"orianna",
            type:"Pháp sư / Hỗ trợ",
            difficult:2,
            damagetype:"100% Phép Thuật",
            image:"orianna_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Seraphine",
            url:"seraphine",
            type:"Pháp sư / Hỗ trợ",
            difficult:1,
            damagetype:"100% Phép Thuật",
            image:"seraphine_champthumb",
            skinindex:2,
            show:false
        ),
        Champion(
            name:"Shyvana",
            url:"shyvana",
            type:"Đấu sĩ / Đỡ đòn",
            difficult:1,
            damagetype:"100% Vật Lý",
            image:"Shyvana_ChampThumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Singed",
            url:"singed",
            type:"Đỡ đòn / Pháp sư",
            difficult:2,
            damagetype:"100% Phép Thuật",
            image:"singed_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Sona",
            url:"sona",
            type:"Hỗ trợ / Pháp sư",
            difficult:1,
            damagetype:"100% Phép Thuật",
            image:"sona_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Soraka",
            url:"soraka",
            type:"Hỗ trợ / Pháp sư",
            difficult:1,
            damagetype:"100% Phép Thuật",
            image:"soraka_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Teemo",
            url:"teemo",
            type:"Xạ thủ / Pháp sư",
            difficult:1,
            damagetype:"75% Phép Thuật - 25% Vật Lý",
            image:"Teemo_ChampThumb",
            skinindex:5,
            show:false
        ),
        Champion(
            name:"Tristana",
            url:"tristana",
            type:"Xạ thủ",
            difficult:1,
            damagetype:"38% Phép Thuật - 62% Vật Lý",
            image:"Tristana_ChampThumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Tryndamere",
            url:"tryndamere",
            type:"Đấu sĩ",
            difficult:1,
            damagetype:"100% Vật Lý",
            image:"tryndamere_champthumb",
            skinindex:5,
            show:false
        ),
        Champion(
            name:"Twisted Fate",
            url:"twisted-fate",
            type:"Pháp sư / Xạ thủ",
            difficult:2,
            damagetype:"88% Phép Thuật - 12% Vật Lý",
            image:"twistedfate_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Varus",
            url:"varus",
            type:"Xạ thủ / Pháp sư",
            difficult:2,
            damagetype:"50% Phép Thuật - 50% Vật Lý",
            image:"varus_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Vayne",
            url:"vayne",
            type:"Xạ thủ / Sát thủ",
            difficult:2,
            damagetype:"100% Vật Lý",
            image:"vayne_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"VI",
            url:"vi",
            type:"Đấu sĩ",
            difficult:1,
            damagetype:"100% Vật Lý",
            image:"vi_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Wukong",
            url:"wukong",
            type:"Đấu sĩ / Đỡ đòn",
            difficult:1,
            damagetype:"100% Vật Lý",
            image:"Wukong_ChampThumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Xin Zhao",
            url:"xin-zhao",
            type:"Đấu sĩ / Đỡ đòn",
            difficult:1,
            damagetype:"100% Vật Lý",
            image:"xinzhao_champthumb",
            skinindex:4,
            show:false
        ),
        Champion(
            name:"Rakan",
            url:"rakan",
            type:"Hỗ trợ / Đỡ đòn",
            difficult:2,
            damagetype:"100% Phép Thuật",
            image:"Rakan_ChampThumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Xayah",
            url:"xayah",
            type:"Xạ thủ / Pháp sư",
            difficult:2,
            damagetype:"100% Phép Thuật",
            image:"Xayah_ChampThumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Yasuo",
            url:"yasuo",
            type:"Đấu sĩ / Sát thủ",
            difficult:3,
            damagetype:"13% Phép Thuật - 87% Vật Lý",
            image:"yasuo_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Zed",
            url:"zed",
            type:"Sát thủ",
            difficult:3,
            damagetype:"100% Vật Lý",
            image:"zed_champthumb",
            skinindex:3,
            show:false
        ),
        Champion(
            name:"Ziggs",
            url:"ziggs",
            type:"Pháp sư",
            difficult:2,
            damagetype:"100% Phép Thuật",
            image:"ziggs_champthumb",
            skinindex:3,
            show:false
        )
    ]

