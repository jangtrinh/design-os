//
//  GameDictionary.swift
//  TocChienGuide
//
//  Created by Jang Trinh on 22/02/2021.
//

import SwiftUI

struct Dictionary: Identifiable, Hashable {
    
    var id = UUID()
    var shortname: String
    var fullname: String

}

var dictionaries = [
    Dictionary(
        shortname:"ACE",
        fullname:"có ý nghĩa là Quét Sạch."
    ),
    Dictionary(
        shortname:"AD (Attack Dame)",
        fullname:"có nghĩa là Sát thương Vật Lý, Sức Mạnh Công Kích (SMCK) thường viết nhầm thành at/át xạ thủ. Hay bị nhầm với ADC nên bây giờ hiểu AD là xạ thủ."
    ),
    Dictionary(
        shortname:"ADC (Attack Dame Carry)",
        fullname:"có nghĩa là Xạ Thủ, thường viết nhầm thành ad, át, at / sát thương vật lý. Hay bị ghi nhầm thành AD nên có thể hiểu ADC là xạ thủ."
    ),
    Dictionary(
        shortname:"AFK (Away From Keyboard)",
        fullname:"AFK có nghĩa là người chơi không hoạt động trong game hoặc bị mất kết nối. Nếu có ai đó bảo bạn AFK thì tức là bảo bạn nghỉ game này đi."
    ),
    Dictionary(
        shortname:"Aggro/Aggressio",
        fullname:"Thành mục tiêu của Lính hoặc Trụ."
    ),
    Dictionary(
        shortname:"AI (Artificial Intelligence)",
        fullname:"có nghĩa là Máy đấu với máy được lập trình sẵn (tương tự như bot)."
    ),
    Dictionary(
        shortname:"AoE (Area of Effect)",
        fullname:"Chiêu thức diện rộng, khả năng đánh lan."
    ),
    Dictionary(
        shortname:"AP (Ability Power)",
        fullname:"Sức mạnh phép thuật (SMPT)."
    ),
    Dictionary(
        shortname:"Ap Ratio",
        fullname:"Tỷ lệ sức mạnh phép thuật, chỉ khả năng tăng sức mạnh phép thuật lên theo tỷ lệ."
    ),
    Dictionary(
        shortname:"AR (Armor)",
        fullname:"Giáp, tăng khả năng giảm sát thương Vật Lý."
    ),
    Dictionary(
        shortname:"Aram",
        fullname:"Tên một bản đồ 5v5 tướng ngẫu nhiên với 1 lane Vực Gió Hú."
    ),
    Dictionary(
        shortname:"ArP (Armor Penetration)",
        fullname:"Xuyên giáp (sát lực), tăng sát thương vật lý gây ra bằng cách bỏ qua một phần giáp (trực tiếp hoặc tỷ lệ)."
    ),
    Dictionary(
        shortname:"AS (Attack Speed)",
        fullname:"Tốc độ đánh."
    ),
    Dictionary(
        shortname:"Assasin",
        fullname:"Sát thương lớn, khả năng linh động cao, có thể giết kẻ địch và trốn thoát ngay lập tức nhưng khả năng phòng thủ khá mỏng vậy nên gặp hiệu ứng khống chế là chết nhanh."
    ),
    Dictionary(
        shortname:"Auto Attack",
        fullname:"Đòn đánh tự động vào quái hoặc tướng, bất kỳ tướng nào cũng sẽ có đòn đánh tự động."
    ),
    Dictionary(
        shortname:"Auto Reset",
        fullname:"Đòn đánh giúp làm ngắn thời gian nghỉ giữa các đòn đánh tự động. Có thể sử dụng bằng cách đánh tự động sau đó sử dụng kỹ năng rồi đánh ngay lập tức sẽ giúp người chơi tấn công tự động nhanh hơn."
    ),
    Dictionary(
        shortname:"B Back",
        fullname:"Lùi về/quay lại, đây cũng là phím tắt để về bệ đá cổ."
    ),
    Dictionary(
        shortname:"Backdoor",
        fullname:"Đẩy đường hoặc trụ mà địch không biết hoặc không về kịp."
    ),
    Dictionary(
        shortname:"BG (Bad Game)",
        fullname:"Thuật ngữ lol chỉ một trận đấu tồi tệ."
    ),
    Dictionary(
        shortname:"Bait/Baiting",
        fullname:"Dụ địch, có nghĩa là khiến đối phương làm theo chủ đích của mình Blue: Bãi quái rừng Khổng lồ Đá xanh, Bùa Xanh. Là một Bùa lợi thấu thị cho 10% giảm hồi chiêu và hồi mana nhanh hơn trong 2'30s. Còn nhường Blue tức là nhường bùa xanh ấy."
    ),
    Dictionary(
        shortname:"Baron",
        fullname:"Là 1 con sâu tím khổng lồ sẽ được thay thế cho quái Herald vào giai đoạn cuối game. Khi giết được Baron sẽ giúp cho người chơi và đồng đội có thể bùa lợi giúp tăng sát thương phép, sát thương vật lý và thời gian biến về nhanh hơn cũng như buff cho lính mình mạnh hơn rất nhiều. Bạn mất bùa lợi của Baron khi bạn chết. Ngay khi có Baron thì thường sẽ sử dụng chiến thuật đẩy 3 đường cùng 1 lúc vì bùa lợi có tác dụng giúp lính mạnh hơn nên đẩy đường sẽ nhanh hơn."
    ),
    Dictionary(
        shortname:"Battle Mage",
        fullname:"Là những pháp sư có kỹ năng tầm gần nhưng có lượng sát thương cao và gây sát thương liên tục trong 1 khoảng thời gian rồi mới kết liễu kẻ địch."
    ),
    Dictionary(
        shortname:"Blue Motes",
        fullname:"Là tiền tệ trong LMHT Tốc Chiến để mua tướng và nhiều vật dụng khác. Cách tốt nhất để bạn kiếm Blue Mote là tích cực cày game. Các chế độ chơi trong Liên Minh Tốc Chiến sẽ trao cho bạn số lượng phần thưởng khác nhau sau khi giành chiến thắng."
    ),
    Dictionary(
        shortname:"Bot",
        fullname:"Có nghĩa là Máy, người dùng sẽ đấu với máy được lập trình sẵn (tương tự như AI)."
    ),
    Dictionary(
        shortname:"Bot (Bottom/Bot lane)",
        fullname:"Đường dưới hoặc người chơi đi đường dưới thường là ADC và Hỗ trợ."
    ),
    Dictionary(
        shortname:"BrB (Be Right Back)",
        fullname:"Có nghĩa là quay lại ngay, là rời khỏi để hồi máu, mua đồ hoặc làm gì đó rồi quay lại nhanh bằng tele hay skill."
    ),
    Dictionary(
        shortname:"Bruiser",
        fullname:"Võ sĩ là các tướng có chỉ số tấn công cao rất mạnh vào giai đoạn đầu game và giữa game nhưng lại hạn chế về khả năng di chuyển. Những tướng này thường nên có 1 - 2 món đồ tấn công rồi sau đó mới bắt đầu lên các món đồ chống chịu. Đây là những tướng có sát thương hơn tướng tank nhưng cũng có 1 ít khả năng chống chịu để không bị chết quá nhanh trong khi giao tranh."
    ),
    Dictionary(
        shortname:"Buff",
        fullname:"Tăng sức mạnh/máu/giáp. Tướng buff tức là sử dụng skill/trang bị/phép bổ trợ để đặt lên đồng minh hiệu ứng tốt/đối thủ hiệu ứng xấu."
    ),
    Dictionary(
        shortname:"Burst Mage",
        fullname:"Tướng pháp sư dồn sát thương là những tướng có kỹ năng tầm khá gần nhưng lại có lượng sát thương vô cùng lớn giúp bạn ó thể diệt kẻ địch trong 1 combo duy nhất."
    ),
    Dictionary(
        shortname:"Camp",
        fullname:"Cắm trại, gank liên tục lên 1 đường. Thường ám chỉ việc bị rừng gank liên tục."
    ),
    Dictionary(
        shortname:"Care",
        fullname:"Cẩn thận."
    ),
    Dictionary(
        shortname:"Carry",
        fullname:"Tướng gánh team về cuối game. Có nghĩa là những tướng cần trang bị để có sức mạnh giai đoạn sau trận đấu, đầu game cần farm nhiều để có vàng."
    ),
    Dictionary(
        shortname:"CB (Combat)",
        fullname:"Có nghĩa là Trận đánh."
    ),
    Dictionary(
        shortname:"CC (Crowd Control)",
        fullname:"Kỹ năng khống chế, có 2 dạng khống chế là khống chế cứng (Hard CC) và khống chế mềm (Soft CC)."
    ),
    Dictionary(
        shortname:"CD (Cooldown)",
        fullname:"Thời gian hồi chiêu, khi bạn nói thuật ngữ LOL này thì đồng đội sẽ hiểu bạn hồi chiêu chưa xong."
    ),
    Dictionary(
        shortname:"CDR (Cooldown Reduction)",
        fullname:"Giảm thời gian hồi chiêu."
    ),
    Dictionary(
        shortname:"Champ (Champion)",
        fullname:"Tướng/Anh hùng."
    ),
    Dictionary(
        shortname:"Channel",
        fullname:"Tướng của bạn không thể di chuyển hoặc sử dụng các kỹ năng khác khi đang sử dụng kỹ năng phải gồng năng lượng."
    ),
    Dictionary(
        shortname:"Collapse (Flank)",
        fullname:"Cô lập team địch và móc vào phía sau team địch."
    ),
    Dictionary(
        shortname:"Combo",
        fullname:"Liên hoàn chiêu thức. Bạn có thể hiểu là sử dụng chiêu thức của tướng theo công thức chuẩn. Đây là cách sử dụng kỹ năng theo trình tự để đạt hiệu quả cao nhất."
    ),
    Dictionary(
        shortname:"Counter Jungle",
        fullname:"Cướp rừng đối phương."
    ),
    Dictionary(
        shortname:"Cover",
        fullname:"Bảo kê/Yểm trợ, có nghĩa là hỗ trợ cho đồng minh."
    ),
    Dictionary(
        shortname:"CR (Creep)",
        fullname:"Lính xe hoặc lính pháo, ngoài ra có thể là quái rừng nếu tính chỉ số farm."
    ),
    Dictionary(
        shortname:"CrC (Critical Strike Chance)",
        fullname:"Tỷ lệ chí mạng, tăng cơ hội đánh chí mạng."
    ),
    Dictionary(
        shortname:"CrD (Critical Strike Damage)",
        fullname:"Sát thương của đòn đánh chí mạng, nghĩa là tăng lượng sát thương gây ra của đòn đánh chí mạng."
    ),
    Dictionary(
        shortname:"CS (Creep Score)",
        fullname:"Chỉ số farm (Lính + quái rừng)."
    ),
    Dictionary(
        shortname:"Đánh thuế",
        fullname:"Đứng lại ăn lính của lane khác sau khi gánh team, thường áp dụng cho người đi Rừng."
    ),
    Dictionary(
        shortname:"Đẩy lẻ",
        fullname:"Đẩy đường 1 mình sau giai đoạn đi đường, thường chia theo 1-4 hay 1-3-1 và không phải tướng nào cũng có thể đẩy lẻ một mình. Một vài tướng có thể đẩy lẻ như Jax, Fiora, Camile, Singed,... và các tướng tank."
    ),
    Dictionary(
        shortname:"Dis (Disconnect)",
        fullname:"Có nghĩa là mất kết nối, hay bị viết nhầm thành đit, đít. Nói chung là dễ bị hiểu nhầm thành chửi bậy."
    ),
    Dictionary(
        shortname:"Dive (Tower Diving)",
        fullname:"Đi vào trong tầm ngắm trụ."
    ),
    Dictionary(
        shortname:"DoT (Damage over Time)",
        fullname:"Sát thương theo thời gian."
    ),
    Dictionary(
        shortname:"Đồng đoàn",
        fullname:"Rank thấp nhất trong LMHT nhưng thường được hiểu theo nghĩa bị chửi việc đánh ngu hoặc không biết chơi. Một số tên tương tự như Rank Đồng, Nhựa Đoàn, Gỗ Đoàn, Cu Đoàn..."
    ),
    Dictionary(
        shortname:"Đóng băng lính",
        fullname:"Giữ thế lính không thay đổi (thường là last hit) khiến đối thủ không thể farm hay tránh bị gank."
    ),
    Dictionary(
        shortname:"DPS (Damage Per Second)",
        fullname:"Gây ra một lượng sát thương lớn trong thời gian ngắn, hay còn gọi là dồn damage."
    ),
    Dictionary(
        shortname:"Dragon",
        fullname:"Là những con quái vật rồng. 2 rồng đầu tiên sẽ có nguyên tố ngẫu nhiên nhưng từ con rồng thứ 2 khi giết sẽ làm cho địa hình của bản đồ thay đổi tương ứng với nguyên tố đó. Có 4 loại rồng tương ứng 4 nguyên tố: lửa, nước, gió, đất."
    ),
    Dictionary(
        shortname:"Dragon Ocean Drake",
        fullname:"Rồng nước tăng khả năng hồi phục."
    ),
    Dictionary(
        shortname:"Dragon Mountain Drake",
        fullname:"Rồng đất tăng điểm chống chịu."
    ),
    Dictionary(
        shortname:"Dragon Cloud Drake",
        fullname:"Rồng gió giảm thời gian hồi chiêu của kỹ năng cuối."
    ),
    Dictionary(
        shortname:"Dragon Infernal Drake",
        fullname:"Rồng lửa tăng chỉ số tấn công."
    ),
    Dictionary(
        shortname:"Duelist",
        fullname:"Đấu Sĩ, mạnh trong khi giao tranh 1 vs 1 với sát thương lớn nhưng yếu về phòng thủ. Họ có thể tách đường để đẩy và gây áp lực ở các đường khác trong khi nguyên team sẽ đi 1 đường khác. Những tướng này không phải là không thể tham gia chiến đầu cùng đồng đội nhưng vì kỹ năng của họ gần như không phát huy quá nhiều tác dụng khi chiến đấu cùng đồng đội."
    ),
    Dictionary(
        shortname:"Early game/ Laning Phase",
        fullname:"Giai đoạn đầu game, đây là lúc mà tướng rừng hoạt động liên tục vừa fam lên cấp vừa đi các đường khác nhau để quấy rối đối phương để dành lợi thế cho các tướng ở các đường."
    ),
    Dictionary(
        shortname:"ELO",
        fullname:"Hệ thống điểm dựa trên các chỉ số trong mỗi trận đấu. Thường được viết High Elo với nghĩa là Chiến thắng liên tiếp nhiều trận đấu hoặc Hell Elo với nghĩa Thua liên tiếp nhiều trận đấu."
    ),
    Dictionary(
        shortname:"Enchanter",
        fullname:"Là người buff hồi máu hoặc buff khiện cho đồng đội. Thường những tướng này sẽ đi theo trợ giúp cho ADC. Những tướng này thường có yêu cầu về trang bị thấp hơn những tướng khác nhưng vẫn gây hiệu quả cao trong giao tranh."
    ),
    Dictionary(
        shortname:"Execute",
        fullname:"Kỹ năng hoặc hiệu ứng gây sát thương cao nhầm đảm bảo cho kẻ địch sẽ chết."
    ),
    Dictionary(
        shortname:"Facecheck",
        fullname:"Kiểm tra bụi cỏ."
    ),
    Dictionary(
        shortname:"Exp (Experience)",
        fullname:"Điểm kinh nghiệm để lên cấp."
    ),
    Dictionary(
        shortname:"Faker",
        fullname:"Người chơi có kỹ năng tốt. Hàm ý khen ai đó giỏi hoặc giỏi đột xuất."
    ),
    Dictionary(
        shortname:"Farm (Farming)",
        fullname:"Hành động giết lính/quái rừng để kiếm vàng."
    ),
    Dictionary(
        shortname:"Fed",
        fullname:"Kiếm được nhiều tiền sau khi giết nhiều tướng địch."
    ),
    Dictionary(
        shortname:"Feed/Feeder",
        fullname:"(Người) chết nhiều mạng hơn việc ăn được mạng trong trận đấu. Ai mà chết liên tục thì sẽ bị chửi là feeder."
    ),
    Dictionary(
        shortname:"FF",
        fullname:"Đầu hàng, cụm từ bình chọn đầu hàng với câu lệnh /ff."
    ),
    Dictionary(
        shortname:"Flash",
        fullname:"Phép bổ trợ Tốc biến."
    ),
    Dictionary(
        shortname:"Gank",
        fullname:"Combat mà có thêm đồng minh từ lane khác giúp đỡ, thường chỉ việc Rừng ra lane bất ngờ hay các lane khác can dự vào 1 lane nào đó."
    ),
    Dictionary(
        shortname:"GG (Good Game)",
        fullname:"Có nghĩa là việc kết thúc một trận đấu hay, hiện từ này đã bị hiểu thành đầu hàng rồi."
    ),
    Dictionary(
        shortname:"GGWP (Good Game Well Played)",
        fullname:"Tương tự như Good Game."
    ),
    Dictionary(
        shortname:"GOSU",
        fullname:"Người chơi có kỹ năng cá nhân tốt, khi nói ra có hàm ý khen kỹ năng ai đó."
    ),
    Dictionary(
        shortname:"GP5 (Gold Regen)",
        fullname:"Lượng vàng tăng lên mỗi 5s."
    ),
    Dictionary(
        shortname:"Grievous Wounds",
        fullname:"Là kỹ năng giảm lượng hồi máu của tướng khi tướng đó chịu tác dụng của hiệu ứng vết thương sâu."
    ),
    Dictionary(
        shortname:"Harass",
        fullname:"Cấu máu/rỉa máu, gây khó chịu cho đối thủ."
    ),
    Dictionary(
        shortname:"Hard CC",
        fullname:"Kỹ năng khống chế gồm trói, choáng, hất tung, đẩy lùi,... khiến cho mục tiêu không thể di chuyển theo ý mình muốn."
    ),
    Dictionary(
        shortname:"Herald",
        fullname:"Là quái lớn nằm ở khu vực Baron. Nếu giết được nó trong vài phút đầu bạn sẽ được nhận mắt của Herald. Đội nào giết chết được Herald thì đồng đội sẽ có thể lượm được con mắt của Herald từ đó gọi lên 1 con Herald ở các đường khác nhau nhằm mục tiêu đẩy trụ nhanh hơn. Cách giết Herald chính là nhắm vào con mắt ở phía sau nó. Khi tấn công vào mắt sẽ giúp bạn gây 1 lượng sát thương lớn và giết nó nhanh hơn rất nhiều."
    ),
    Dictionary(
        shortname:"HP (Hit Point, Health Points)",
        fullname:"Chỉ số máu."
    ),
    Dictionary(
        shortname:"HP5 (Health Regen)",
        fullname:"Lượng máu hồi phục mỗi 5s."
    ),
    Dictionary(
        shortname:"IAS (Increased Attacks Speed)",
        fullname:"Tăng tốc độ đánh."
    ),
    Dictionary(
        shortname:"Imba",
        fullname:"Thuật ngữ lmht chỉ trình bá đạo, thể hiện trình độ cao của game thủ."
    ),
    Dictionary(
        shortname:"Initiate",
        fullname:"Giáp chiến/Bắt đầu combat."
    ),
    Dictionary(
        shortname:"Invade",
        fullname:"Xâm nhập rừng đối phương."
    ),
    Dictionary(
        shortname:"Inzumin nhập",
        fullname:"Leesin sóng âm trượt, Inzumin từng thi đấu chuyên nghiệp trong màu áo của Saigon Jokers, giờ là bình luận viên. Hàm ý game thủ này chơi như kiểu Inzumin vậy."
    ),
    Dictionary(
        shortname:"Juke/Juking",
        fullname:"Lừa đối phương để thoát khỏi sự truy sát."
    ),
    Dictionary(
        shortname:"Jungle/Forest",
        fullname:"Đường rừng hoặc những tướng đi trong rừng và giết quái rừng để lấy thêm tiền và kinh nghiệm. Mục tiêu của tướng rừng là cướp những quái có lợi cho bản thân và di chuyển liên tục để gây áp lực lên các đường khác."
    ),
    Dictionary(
        shortname:"Kill",
        fullname:"Ý là giết người hoặc quái, hay bị viết nhầm thành Skill/Kỹ năng."
    ),
    Dictionary(
        shortname:"Kite/Kiting",
        fullname:"Thả diều hay gọi Hit and Run, là thuật ngữ LOL chỉ cách vừa chạy vừa đánh để giữ khoảng cách với đối thủ mà vẫn gây ra sát thương và hủy động tác thừa, chỉ có tướng tay dài mới làm được."
    ),
    Dictionary(
        shortname:"KS (Kill Steal)",
        fullname:"Cướp mạng mà đồng minh sắp ăn được, nói đến việc không phải người gây ra hầu hết sát thương nhưng lại là người ăn được mạng."
    ),
    Dictionary(
        shortname:"Lane",
        fullname:"Thuật ngữ chỉ đường đi của lính, thông thường có 3 lane là TOP, MID, và BOT nhưng Jungle có khi cũng được tính là 1 lane."
    ),
    Dictionary(
        shortname:"Last Hit",
        fullname:"Thuật ngữ lol chỉ đòn đánh kết liễu để nhận được vàng, ngoài ra còn với mục đích đóng băng thế lính, không cho đối thủ farm."
    ),
    Dictionary(
        shortname:"Lead",
        fullname:"Dẫn trước, có thể là về kinh nghiệm hoặc về số vàng kiếm được."
    ),
    Dictionary(
        shortname:"Lease",
        fullname:"Kéo quái để đồng đội đánh, nhận sát thương từ quái."
    ),
    Dictionary(
        shortname:"Lethality",
        fullname:"Xuyên giáp tùy theo cấp của tướng."
    ),
    Dictionary(
        shortname:"Leaver",
        fullname:"Chỉ người thoát game khi chưa kết thúc trận đấu."
    ),
    Dictionary(
        shortname:"Lv (Level)",
        fullname:"Cấp độ tướng trong game, hay bị viết nhầm là Lever. Khi lên level bạn sẽ tăng nhiều chỉ số và có thêm điểm cộng skill."
    ),
    Dictionary(
        shortname:"Mana",
        fullname:"Là nguồn năng lượng của hầu hết các tướng và sẽ hồi lại khi trở về nhà hoặc theo thời gian."
    ),
    Dictionary(
        shortname:"Meta/Metagame",
        fullname:"Lối chơi, chiến thuật phù hợp nhất với từng giai đoạn của mùa giải, thường được khởi xướng bởi 1 đội nào đó trong giải đấu LMHT chuyên nghiệp. Được chứng minh là hiệu quả và phù hợp với các tình huống khác nhau."
    ),
    Dictionary(
        shortname:"MIA (Missing in Action)",
        fullname:"Mất dấu đối thủ, không thể đoán được hành động của họ."
    ),
    Dictionary(
        shortname:"Mid (Middle)",
        fullname:"Thuật ngữ chỉ vị trí đường giữa hoặc người chơi đường giữa."
    ),
    Dictionary(
        shortname:"Mid game",
        fullname:"Là khoảng thời gian khi mà có trụ đầu tiên bị hạ hoặc bắt đầu ăn được 1 2 vài con rông thì lúc này các tướng ở các đường khác nhau bắt đầu hoạt động chung vì 1 số mục tiêu như là trụ địch, rồng, hoặc Herald."
    ),
    Dictionary(
        shortname:"Mid Lane",
        fullname:"Đường giữa, Thường dành cho sát thủ, pháp sư giúp họ lên cấp nhanh hơn và có được trang bị mạnh trong thời gian ngắn. Sau đó sẽ di chuyển ở các đường khác để gây áp lực lên đối phương."
    ),
    Dictionary(
        shortname:"Misaya",
        fullname:"Ý nghĩa được hiểu là Combo Twisted Fate: Định Mệnh (R) + Bài Vàng giữa lòng team địch + Đồng Hồ Cát. Thường được viết thành Mit, mít, mis, miss. Misaya là game thủ chuyên nghiệp của Team WE. Vào những mùa đầu tiên luôn phải cấm Twisted Fate của Misaya. Tục truyền rằng Misaya là game thủ duy nhất tính được chu kỳ chọn bài của W khi đang trong thời gian hồi."
    ),
    Dictionary(
        shortname:"MOBA (Multiplayer Online Battle Area)",
        fullname:"Đây là một thể loại game PVP công thành trên bản đồ hình vuông được chia thành 3 đường như LMHT, Dota, 3Q."
    ),
    Dictionary(
        shortname:"MP (Mana Points)",
        fullname:"Chỉ số năng lượng (phía dưới thanh máu), không phải tướng nào cũng có thanh mana."
    ),
    Dictionary(
        shortname:"MP5 (Mana Regen)",
        fullname:"Lượng năng lượng hồi phục mỗi 5s."
    ),
    Dictionary(
        shortname:"MPen, MrP (Magic Penetration)",
        fullname:"Chỉ xuyên kháng phép, tăng sát thương phép gây ra bằng cách bỏ qua một phần kháng phép (trực tiếp hoặc tỷ lệ)."
    ),
    Dictionary(
        shortname:"MR (Magic Resist)",
        fullname:"Trang bị kháng phép, chống lại sức mạnh phép thuật."
    ),
    Dictionary(
        shortname:"MS (Movement Speed)",
        fullname:"Tốc độ di chuyển."
    ),
    Dictionary(
        shortname:"Noob (Newbie)",
        fullname:"Thuật ngữ này chỉ người mới học chơi, gà mờ."
    ),
    Dictionary(
        shortname:"Nerf (Nerfed)",
        fullname:"Giảm sức mạnh của tướng đang quá bá so với phần còn lại để cân bằng game. Không chỉ tướng đang mạnh mới bị nerf mà những tướng phù hợp với 1 lối đánh, hay kiểu lên đồ quá bá cũng có thể bị nerf."
    ),
    Dictionary(
        shortname:"Objectives",
        fullname:"Mục tiêu chung giúp bạn có thể chiến thắng trận đấu. Đó có thể là rồng, Herald, Barons hay trụ địch hoặc nhà cuối của địch."
    ),
    Dictionary(
        shortname:"Offtank (Offensive Tank)",
        fullname:"Thuật ngữ chỉ tanker dự phòng (khi tank chính không thể vào combat)"
    ),
    Dictionary(
        shortname:"OOM (Out of mana)",
        fullname:"Hết mana, tình trạng không đủ năng lượng để sử dụng skill."
    ),
    Dictionary(
        shortname:"On-hit",
        fullname:"Hiệu ứng được bổ sung vào các đòn đánh tay hoặc 1 số kỹ năng được xem là đòn đánh tay nhưng có cộng thêm sát thương cho đòn đánh tay đó."
    ),
    Dictionary(
        shortname:"OP (Overpowered)",
        fullname:"Kẻ mạnh (trong ván đấu)."
    ),
    Dictionary(
        shortname:"Open Mid",
        fullname:"Câu nói chỉ việc để team địch all mid chiến thắng nhanh ván đấu. Bạn có thể dùng ở mọi nơi nhưng câu nói này chủ yếu được dùng tại Hàn Quốc. Bởi nơi đây có nhiều điều kiện chơi game nên người chơi muốn thua nhanh để làm trận mới khi thiếu người hay thua lane.."
    ),
    Dictionary(
        shortname:"Outmeta",
        fullname:"Chỉ việc một vị tướng không còn phù hợp (hay ít được chơi) tại một phiên bản nào đó của LMHT. Outmeta không hẳn là yếu, mà là hợp với meta mới hơn. Những vị tướng outmeta thường sẽ được Riot để và chỉnh sửa sức mạnh."
    ),
    Dictionary(
        shortname:"Outplay",
        fullname:"Việc lật ngược từ thua thành thắng trong combat. Thường có ý nghĩa sử dụng skill để chiến thắng hoặc trốn thoát đối thủ khi đang bị truy đuổi. Những pha outplay đẹp thường sẽ được thấy khi solo lane."
    ),
    Dictionary(
        shortname:"Peel",
        fullname:"Giữ cho kẻ địch tranh xa khỏi đồng đội, có thể thực hiện bằng việc bồi 1 lượng lớn sát thương hoặc liên tục khống chế kẻ địch."
    ),
    Dictionary(
        shortname:"Ping",
        fullname:"Tín hiệu giúp thông báo trong game giữa các đồng đội."
    ),
    Dictionary(
        shortname:"Poke (Poking)",
        fullname:"Quấy rối hoặc cấu máu đối phương ở khoảng cách xa bằng skill diện rộng."
    ),
    Dictionary(
        shortname:"Poke Mage",
        fullname:"Tướng pháp sư cấu rỉa. Chỉ những tướng có tầm kỹ năng rất xa giúp cấu rỉa máu tốt. Những tướng này sẽ hạ gục bạn ngay khi máu của bạn xuống vừa đủ thấp để họ dồn toàn bộ kỹ năng vào mặt bạn."
    ),
    Dictionary(
        shortname:"Poro Points",
        fullname:"Là một loại tiền tệ chỉ có duy nhất trong LMHT Tốc Chiến giúp bạn mua được rất nhiều vật phẩm thú vị không đâu có như các biểu tượng, biểu cảm, hoạt ảnh biến về, tư thế và cả skin tướng nữa đấy."
    ),
    Dictionary(
        shortname:"Priority",
        fullname:"Kỹ năng giúp bạn ngay lập tức tiếp cứu cho đồng đội hoặc giúp đẩy đường lên cao giúp phá nhà đối phương nhanh nhất."
    ),
    Dictionary(
        shortname:"Proxy",
        fullname:"Ăn lính sau trụ."
    ),
    Dictionary(
        shortname:"Pushing",
        fullname:"Đẩy đường và giết lính với ý định phá trụ, hay còn được gọi là Push trụ."
    ),
    Dictionary(
        shortname:"Quăng game",
        fullname:"Tăng độ khó cho game, hay bạn có thể là việc team đang có lợi thế nên bạn hoặc ai đó trong team thích thể hiện hay cố ăn mạng để phá vỡ đội hình. Hậu quả là sẽ bị lật kèo hoặc có highlight cân team."
    ),
    Dictionary(
        shortname:"Re",
        fullname:"Xuất hiện trở lại (kẻ địch)."
    ),
    Dictionary(
        shortname:"Recast",
        fullname:"Kỹ năng có thể sử dụng nhiều lần."
    ),
    Dictionary(
        shortname:"Red",
        fullname:"Bùa đỏ/Bãi quái rừng Bụi gai đỏ thành tinh. Bùa lợi Tro Tàn cho khả năng hồi máu ngoài giao tranh và đòn đánh thiêu đốt + làm chậm kẻ địch trong thời gian 2'30s. Nếu xin Red là muốn bạn nhường bùa đỏ."
    ),
    Dictionary(
        shortname:"River",
        fullname:"Sông cắt ngang ở giữa bản đồ."
    ),
    Dictionary(
        shortname:"Roam",
        fullname:"Đảo đường hay đảo qua các lane khác nhằm mục đích gank như rừng."
    ),
    Dictionary(
        shortname:"Rune",
        fullname:"Ngọc bổ trợ/ Bảng ngọc"
    ),
    Dictionary(
        shortname:"Scales",
        fullname:"Kỹ năng/ Chiêu thức mạnh hơn nhờ có vật phẩm."
    ),
    Dictionary(
        shortname:"Scaling",
        fullname:"Kỹ năng/Chiêu thức mạnh hơn nhờ Ngọc."
    ),
    Dictionary(
        shortname:"Shove",
        fullname:"Đẩy lính lên cao tới trụ địch nhanh hơn để dồn ép đối phương."
    ),
    Dictionary(
        shortname:"Skill",
        fullname:"Kỹ năng/Chiêu thức của vị tướng."
    ),
    Dictionary(
        shortname:"Skill Shot",
        fullname:"Kỹ năng định hướng, chiêu thức đi theo hướng được định sẵn."
    ),
    Dictionary(
        shortname:"Skill Target",
        fullname:"Chiêu thức/Kỹ năng chọn mục tiêu. Kỹ năng bay đến thẳng mục tiêu đã được chỉ định."
    ),
    Dictionary(
        shortname:"Soft CC",
        fullname:"Kỹ năng khống chế làm chậm, câm lặng,... gây bất lợi cho đối phương."
    ),
    Dictionary(
        shortname:"Smite",
        fullname:"Phép bổ trợ trừng phạt."
    ),
    Dictionary(
        shortname:"Smurf",
        fullname:"Nói đến việc người hạng cao chơi nick hạng thấp để giành chiến thắng. Nói một cách dễ hiểu thì đây là cày thuê, kéo rank..."
    ),
    Dictionary(
        shortname:"Snowball",
        fullname:"Lăn cầu tuyết, chỉ việc đẩy mạnh những lợi thế nhỏ chuyển thành lợi thế lớn hơn."
    ),
    Dictionary(
        shortname:"Solo (Solo Queue)",
        fullname:"Đây là đấu hạng đơn nhưng bạn có thể hiểu là việc đánh hạng 1 mình của các cao thủ để thể hiện kỹ năng (streamer chẳng hạn)."
    ),
    Dictionary(
        shortname:"SP (Support)",
        fullname:"Chỉ vị trí hỗ trợ."
    ),
    Dictionary(
        shortname:"Take down",
        fullname:"Nhận 1 điểm kết liễu hoặc hỗ trợ trên việc giết chết tướng địch."
    ),
    Dictionary(
        shortname:"Tank (Tanker)",
        fullname:"Thuật ngữ chỉ người hứng chịu hầu hết sát thương, thường đi tiên phong trong đội."
    ),
    Dictionary(
        shortname:"Team Fight",
        fullname:"Thuật ngữ chỉ Combat 5v5."
    ),
    Dictionary(
        shortname:"Tenacity",
        fullname:"Khả năng chống chịu lại các trạng thái bất lợi như giúp giảm thời gian chịu các kỹ năng khống chế. "
    ),
    Dictionary(
        shortname:"Tele/TP (Teleport)",
        fullname:"Phép bổ trợ Dịch chuyển nhanh."
    ),
    Dictionary(
        shortname:"TeLEPort",
        fullname:"Chỉ pha dịch chuyển nhanh nhưng mà không chính xác. Cụ thể, pha dịch chuyển của LEP với Lulu vào giữa lòng team địch C9 trong khi đang bị trụ bắn và đáp xuống với 1/4 máu."
    ),
    Dictionary(
        shortname:"Top",
        fullname:"Thuật ngữ chỉ đường trên hoặc người đi đường trên."
    ),
    Dictionary(
        shortname:"Top Lane (Herald/Baron Lane)",
        fullname:"Đường trên là khúc đường ngay gần khu vực xuất hiện Herald và Baron."
    ),
    Dictionary(
        shortname:"Trade",
        fullname:"Trao đổi chiêu hay trao đổi sát thương là chỉ việc người chơi sử dụng đòn đánh tay hay kỹ năng dể gây sát thương lên kẻ địch sao cho sau cuộc trao đổi thì đối phương mất nhiều máu hơn mình, thường các tướng đánh xa hoặc các tướng có thêm kỹ năng tạo khiên sẽ lợi thế hơn."
    ),
    Dictionary(
        shortname:"Troll (Troller)",
        fullname:"Kẻ gây rối, phá đám trong trận đấu. Cố tình chết, chửi bậy, lối lên đồ không phù hợp, tranh lane, phá team và phá game. Thường là trẻ trâu."
    ),
    Dictionary(
        shortname:"True damage",
        fullname:"Sát thương chuẩn, không bị giảm bởi bất kỳ nguồn kháng nào."
    ),
    Dictionary(
        shortname:"TT (Twisted Treeline)",
        fullname:"Tên bản đồ 3vs3 Khu Rừng Quỷ Dị."
    ),
    Dictionary(
        shortname:"Turret/Tower",
        fullname:"Những trụ công trình bắn ra các tia laser để phòng thủ khỏi kẻ địch và lính, trong 1 bản đồ sẽ có 3 đường đi gồm đường trên đường giữa và đường dưới, mỗi đường sẽ có 3 trụ phòng thủ được trải từ đều cho đến trụ nhà chính, Những trụ này sẽ ưu tiên tấn công lính nhưng nếu người chơi gây sát thương lên tướng địch trong phạm vi trụ địch thì trụ sẽ ưu tiên tấn công người chơi."
    ),
    Dictionary(
        shortname:"Ulti/Ult/Ultimate/R",
        fullname:"Chiêu cuối cùng, chiêu cuối không phải tướng nào cũng có, hoặc đó chưa chắc đã là skill mạnh nhất. Nhưng thường Ulti sẽ mang lại tính đột biến cao."
    ),
    Dictionary(
        shortname:"UP (Underpowered)",
        fullname:"Tướng/Trang bị/Vật phẩm quá yếu so với mặt bằng chung."
    ),
    Dictionary(
        shortname:"Unstoppable",
        fullname:"Các kỹ năng có hiệu ứng này giúp người chơi không bị dính các kỹ năng."
    ),
    Dictionary(
        shortname:"Xpeke",
        fullname:"Có nghĩa là Backdoor/Phá trụ trộm/Phá nhà chính địch khi không có địch. Bạn có thể xem lại trận Xpeke sử dụng Kassadin backdoor giúp Fnatic chiến thắng với 39 máu + team chết 4 người."
    ),
    Dictionary(
        shortname:"Wombo Combo",
        fullname:"Cũng tương tự như combo nhưng là cách kết hợp chiêu thức của nhiều tướng lại với nhau. Ví dụ như Yasuo kết hợp với Malphite, Orianna, Rakan cùng Missfortune chẳng hạn."
    ),
    Dictionary(
        shortname:"Wild Cores",
        fullname:"Là tiền tệ trong LMHT Tốc Chiến giúp bạn mua được hơn 300 vật phẩm bao gồm trang phục, biểu cảm, hoạt cảnh biến về, hoạt cảnh đặc biệt cho tướng và biểu cảm đặc biệt ở trong Shop Tốc chiến."
    ),
    Dictionary(
        shortname:"Zone (Zoning)",
        fullname:"Khu vực kiểm soát, khu vực có tầm nhìn. Chủ yếu là những khu vực quanh trụ, NPC, tướng, mắt, lính."
    ),
    Dictionary(
        shortname:"Macro Player",
        fullname:"Là những người chơi chuyên nghiệp, khôn ngoan và biết tính toán. Họ không hành động theo bản năng mà suy nghĩ, tính toán kỹ đưa ra chiến lược để dành chiến thắng."
    ),
    Dictionary(
        shortname:"Toxic",
        fullname:"Từ dùng để chỉ 1 người chơi trẻ trâu, bướng, đụng đâu là chửi đó."
    ),
    Dictionary(
        shortname:"Raid",
        fullname:"Là nhiệm vụ trong game yêu cầu thực hiện theo nhóm."
    ),
    Dictionary(
        shortname:"MVP",
        fullname:"Là từ từ viết tắt bởi ”Most Valuable Player” là thuật ngữ dùng để chỉ người chơi có tầm ảnh hưởng lớn đến kết quả của một trận đấu. Tiêu chí để đạt MVP gồm: chỉ số hạ gục tốt, chỉ số hỗ trợ tốt, bị hạ gục càng ít càng tốt, phần trăm sát thương gây ra, phần trăm sát thương nhận vào, các yếu tố về tầm ảnh hưởng như : số lần solo thắng, đóng góp trong giao tranh, hoặc gank thành công, khả năng kiểm soát bản đồ."
    ),
    Dictionary(
        shortname:"Skin",
        fullname:"Trang phục của tướng."
    ),
    Dictionary(
        shortname:"Vibration",
        fullname:"Là chế độ rung phản hồi làm hưng phấn khi chơi game."
    ),
    Dictionary(
        shortname:"Spd",
        fullname:"Viết tắt của Speed : tốc độ."
    ),
    Dictionary(
        shortname:"Mt",
        fullname:"Viết tắt của main tank : Chống chịu chính."
    ),
    Dictionary(
        shortname:"Rùa",
        fullname:"Chỉ hành động vô ý nhưng hiệu quả bất ngờ."
    ),
    Dictionary(
        shortname:"KD/KDA",
        fullname:"Là một chỉ số dùng để đo lường số mạng : giết – chết – hỗ trợ (Kill – Death – Assit) của một game thủ trong trận đấu."
    ),
    Dictionary(
        shortname:"Nội tại",
        fullname:"Mỗi tướng điều có một sức mạnh nội tại riêng, có thể là hồi máu, tăng sát thương, tăng giáp, tốc độ chạy,…"
    )
]
